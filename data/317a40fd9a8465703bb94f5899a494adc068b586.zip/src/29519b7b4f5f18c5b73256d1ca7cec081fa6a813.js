const { test, expect } = require('@playwright/test');

const appleJuice = 'Apple Juice (1000ml)';
const appleJuicePrice = '1.99¤';

function productCards(page) {
  return page.getByRole('main').getByRole('article');
}

async function searchCatalog(page, query) {
  await page.getByRole('button', { name: 'Open search' }).click();
  const searchField = page.getByRole('textbox');
  await searchField.fill(query);
  await searchField.press('Enter');
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Close Welcome Banner' }).click();
  await page.getByRole('button', { name: 'dismiss cookie message' }).click();
});

test('1. Карточка в каталоге показывает название, изображение и цену', async ({ page }) => {
  const card = productCards(page).filter({ has: page.getByText(appleJuice, { exact: true }) });
  await expect(card.getByText(appleJuice, { exact: true })).toBeVisible();
  await expect(card.getByText(appleJuicePrice, { exact: true })).toBeVisible();

  const image = card.getByRole('img', { name: appleJuice, exact: true });
  await expect(image).toBeVisible();
  await expect.poll(() => image.evaluate(img => img.naturalWidth)).toBeGreaterThan(0);
});

test('2. Поиск Banana Juice возвращает одну карточку бананового сока', async ({ page }) => {
  await searchCatalog(page, 'Banana Juice');

  const results = productCards(page);
  await expect(results).toHaveCount(1);
  await expect(results.getByText('Banana Juice (1000ml)', { exact: true })).toBeVisible();
});

test('3. Поиск без совпадений выводит сообщение и скрывает карточки', async ({ page }) => {
  await searchCatalog(page, 'xyz98765');

  await expect(page.getByText('No results found', { exact: true })).toBeVisible();
  await expect(productCards(page)).toHaveCount(0);
});

test('4. При открытии карточки видны название, описание, цена и артикул товара', async ({ page }) => {
  await page.getByRole('img', { name: appleJuice, exact: true }).click();

  const dialog = page.getByRole('dialog');
  await expect(dialog.getByRole('heading', { name: appleJuice, exact: true })).toBeVisible();
  await expect(dialog.getByText('The all-time classic.', { exact: true })).toBeVisible();
  await expect(dialog.getByText(appleJuicePrice, { exact: true })).toBeVisible();
  await expect(dialog.getByText(/^SKU:\s*\S+/i), 'В карточке указан артикул товара (SKU)').toBeVisible();
});

test('5. Переход на вторую страницу меняет товары, а возврат восстанавливает первый товар', async ({ page }) => {
  const cards = productCards(page);
  const firstProductName = cards.first().locator('.name');
  await expect(firstProductName).toHaveText(/\S/);
  const originalName = await firstProductName.innerText();

  await page.getByRole('button', { name: 'Next page' }).click();
  await expect(firstProductName).toHaveText(/\S/);
  await expect(cards.getByText(originalName, { exact: true })).toHaveCount(0);

  await page.getByRole('button', { name: 'Previous page' }).click();
  await expect(firstProductName).toHaveText(originalName);
});
